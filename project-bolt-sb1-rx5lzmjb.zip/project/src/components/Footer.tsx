import React from 'react';
import { Smartphone, Monitor, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 border-t border-green-500/20 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-green-400 to-cyan-400 p-0.5">
                  <div className="w-full h-full rounded-full bg-gray-900 flex items-center justify-center">
                    <div className="flex items-center space-x-1">
                      <Smartphone className="w-3 h-3 text-green-400" />
                      <Monitor className="w-3 h-3 text-cyan-400" />
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="font-bold bg-gradient-to-r from-green-400 to-cyan-400 bg-clip-text text-transparent">
                  MATRIX SYSTEM CARE
                </h3>
              </div>
            </div>
            <p className="text-gray-400 text-sm">
              Your trusted partner for mobile, computer, and technology solutions in Rattinamangalam, ARNI.
            </p>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-bold text-white mb-4">Our Services</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>Mobile Service</li>
              <li>Computer Sales & Service</li>
              <li>Laptop Sales & Services</li>
              <li>Accessories & Spares</li>
              <li>E-Seva & Online Applications</li>
              <li>Printing & Xerox</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-white mb-4">Contact Info</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-2 text-green-400">
                <Phone className="w-4 h-4" />
                <span>76398 14304</span>
              </div>
              <div className="flex items-center space-x-2 text-cyan-400">
                <Phone className="w-4 h-4" />
                <span>96293 87725</span>
              </div>
              <div className="flex items-center space-x-2 text-blue-400">
                <Mail className="w-4 h-4" />
                <span className="break-all">matrixsystemcare19@gmail.com</span>
              </div>
            </div>
          </div>

          {/* Address */}
          <div>
            <h4 className="font-bold text-white mb-4">Address</h4>
            <div className="flex items-start space-x-2 text-sm text-gray-400">
              <MapPin className="w-4 h-4 mt-1 text-purple-400" />
              <div>
                <p>No.116G/3, Ammai Appar Complex,</p>
                <p>E.B.Nagar, Rattinamangalam,</p>
                <p>ARNI - 632 316.</p>
                <p>T.V.Malai Dist.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-gray-400 text-sm">
              © 2024 Matrix System Care. All rights reserved.
            </p>
            <div className="flex items-center space-x-4 text-sm text-gray-400">
              <span>Proprietor: <span className="text-green-400">Dhinesh G</span></span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;