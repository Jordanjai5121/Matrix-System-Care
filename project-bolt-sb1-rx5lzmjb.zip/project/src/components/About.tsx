import React from 'react';
import { Award, Users, Clock, MapPin } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: <Award className="w-8 h-8" />,
      title: 'Professional Service',
      description: 'Expert technicians with years of experience in mobile and computer repairs'
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: 'Customer Focused',
      description: 'Dedicated to providing exceptional customer service and satisfaction'
    },
    {
      icon: <Clock className="w-8 h-8" />,
      title: 'Quick Turnaround',
      description: 'Fast and efficient service delivery for all your technology needs'
    },
    {
      icon: <MapPin className="w-8 h-8" />,
      title: 'Convenient Location',
      description: 'Easily accessible location in Rattinamangalam, ARNI for your convenience'
    }
  ];

  return (
    <section id="about" className="py-20 relative">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="bg-gradient-to-r from-green-400 to-cyan-400 bg-clip-text text-transparent">
                ABOUT US
              </span>
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Your trusted partner for all technology and business service needs
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Content */}
            <div>
              <h3 className="text-2xl md:text-3xl font-bold text-white mb-6">
                Welcome to <span className="text-green-400">Matrix System Care</span>
              </h3>
              
              <div className="space-y-4 text-gray-300 leading-relaxed">
                <p>
                  Matrix System Care is your one-stop destination for comprehensive technology solutions. 
                  Located in the heart of Rattinamangalam, ARNI, we specialize in mobile and computer 
                  sales, service, and repairs.
                </p>
                
                <p>
                  Under the leadership of <span className="text-cyan-400 font-semibold">Dhinesh G</span>, 
                  our team is dedicated to providing professional, reliable, and affordable services 
                  to meet all your technology needs.
                </p>
                
                <p>
                  From mobile repairs to laptop services, from printing solutions to creative resin 
                  art work, we offer a diverse range of services designed to serve both individual 
                  customers and businesses.
                </p>
              </div>

              {/* Contact Person */}
              <div className="mt-8 p-6 bg-gray-900/50 rounded-xl border border-green-500/30">
                <h4 className="text-lg font-bold text-green-400 mb-2">Proprietor</h4>
                <p className="text-xl font-semibold text-white">Dhinesh G</p>
                <p className="text-gray-400">Owner & Service Expert</p>
              </div>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-800 hover:border-green-500/50 transition-all duration-300"
                >
                  <div className="text-green-400 mb-4">
                    {feature.icon}
                  </div>
                  <h4 className="text-lg font-bold text-white mb-2">
                    {feature.title}
                  </h4>
                  <p className="text-gray-400 text-sm">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Services Highlight */}
          <div className="mt-16 text-center">
            <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-xl p-8 border border-green-500/30">
              <h3 className="text-2xl font-bold text-green-400 mb-4">
                Why Choose Matrix System Care?
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-gray-300">
                <div>
                  <h4 className="font-semibold text-white mb-2">✓ Wholesale Available</h4>
                  <p className="text-sm">Competitive wholesale prices for bulk orders</p>
                </div>
                <div>
                  <h4 className="font-semibold text-white mb-2">✓ Genuine Parts</h4>
                  <p className="text-sm">Only authentic spare parts and accessories</p>
                </div>
                <div>
                  <h4 className="font-semibold text-white mb-2">✓ Complete Solutions</h4>
                  <p className="text-sm">All services available under one roof</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;