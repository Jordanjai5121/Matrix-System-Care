import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import MatrixRain from './MatrixRain';

const Layout = () => {
  return (
    <>
      <MatrixRain />
      <Header />
      <main className="relative z-10">
        <Outlet />
      </main>
      <Footer />
    </>
  );
};

export default Layout;