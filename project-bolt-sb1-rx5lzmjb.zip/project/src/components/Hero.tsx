import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-20">
      <div className="container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto">
          {/* Logo Section */}
          <div className="mb-8">
            <div className="relative inline-block">
              <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-r from-green-400 via-cyan-400 to-blue-400 p-1">
                <div className="w-full h-full rounded-full bg-black flex items-center justify-center">
                  <div className="text-2xl font-bold text-white">M</div>
                </div>
              </div>
              <div className="absolute inset-0 rounded-full bg-green-400/30 blur-lg animate-pulse"></div>
            </div>
          </div>

          {/* Main Heading */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6">
            <span className="bg-gradient-to-r from-green-400 via-cyan-400 to-blue-400 bg-clip-text text-transparent">
              MATRIX
            </span>
            <br />
            <span className="text-white">SYSTEM CARE</span>
          </h1>

          {/* Subtitle */}
          <div className="text-xl md:text-2xl lg:text-3xl font-semibold mb-4">
            <span className="text-green-400">MOBILE</span>
            <span className="text-gray-400"> & </span>
            <span className="text-cyan-400">COMPUTER</span>
          </div>
          <p className="text-lg md:text-xl text-blue-400 font-medium mb-8">
            SALES & SERVICE
          </p>

          {/* Service Highlights */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <span className="px-4 py-2 bg-gray-800/80 rounded-full text-white border border-green-500/30">
              Spares & Accessories
            </span>
            <span className="px-4 py-2 bg-gray-800/80 rounded-full text-white border border-cyan-500/30">
              Wholesale Available
            </span>
          </div>

          {/* Contact Info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="flex items-center justify-center space-x-2 text-green-400">
              <Phone size={20} />
              <div>
                <p className="font-semibold">76398 14304</p>
                <p className="text-sm">96293 87725</p>
              </div>
            </div>
            <div className="flex items-center justify-center space-x-2 text-cyan-400">
              <Mail size={20} />
              <p className="font-semibold">matrixsystemcare19@gmail.com</p>
            </div>
            <div className="flex items-center justify-center space-x-2 text-blue-400">
              <MapPin size={20} />
              <p className="font-semibold text-center">Rattinamangalam, ARNI</p>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#services"
              className="px-8 py-3 bg-gradient-to-r from-green-500 to-cyan-500 text-black font-bold rounded-lg hover:from-green-400 hover:to-cyan-400 transition-all duration-300 shadow-lg hover:shadow-green-500/25"
            >
              Explore Services
            </a>
            <a
              href="#contact"
              className="px-8 py-3 border-2 border-green-500 text-green-400 font-bold rounded-lg hover:bg-green-500/10 transition-all duration-300"
            >
              Get In Touch
            </a>
          </div>
        </div>
      </div>

      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-green-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>
    </section>
  );
};

export default Hero;