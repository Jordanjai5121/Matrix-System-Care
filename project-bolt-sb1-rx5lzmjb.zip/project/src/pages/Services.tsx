import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Smartphone, 
  Monitor, 
  Laptop, 
  Wrench, 
  ShoppingCart, 
  Printer, 
  FileText, 
  CreditCard, 
  Palette, 
  BookOpen,
  Megaphone,
  ArrowRight
} from 'lucide-react';

const Services = () => {
  const services = [
    {
      id: 'mobile-service',
      icon: <Smartphone className="w-8 h-8" />,
      title: 'Mobile Service',
      description: 'Professional mobile phone repair and maintenance services',
      color: 'from-green-400 to-green-600',
      features: ['Screen Replacement', 'Battery Service', 'Software Issues', 'Water Damage Repair']
    },
    {
      id: 'computer-sales-service',
      icon: <Monitor className="w-8 h-8" />,
      title: 'Computer Sales & Service',
      description: 'Complete computer solutions, sales, and repair services',
      color: 'from-cyan-400 to-cyan-600',
      features: ['Hardware Repair', 'Software Installation', 'Virus Removal', 'Data Recovery']
    },
    {
      id: 'laptop-service',
      icon: <Laptop className="w-8 h-8" />,
      title: 'Laptop Sales & Services',
      description: 'Laptop sales, repairs, and maintenance services',
      color: 'from-blue-400 to-blue-600',
      features: ['Screen Repair', 'Keyboard Replacement', 'Performance Upgrade', 'Cooling System']
    },
    {
      id: 'accessories',
      icon: <ShoppingCart className="w-8 h-8" />,
      title: 'Accessories',
      description: 'Wide range of mobile and computer accessories',
      color: 'from-purple-400 to-purple-600',
      features: ['Phone Cases', 'Chargers', 'Cables', 'Memory Cards']
    },
    {
      id: 'spares',
      icon: <Wrench className="w-8 h-8" />,
      title: 'Spares & Accessories',
      description: 'Genuine spare parts and accessories - Wholesale available',
      color: 'from-yellow-400 to-yellow-600',
      features: ['Original Parts', 'Wholesale Rates', 'Quality Assured', 'Quick Delivery']
    },
    {
      id: 'e-seva',
      icon: <FileText className="w-8 h-8" />,
      title: 'E-Seva',
      description: 'Digital services and online application assistance',
      color: 'from-green-400 to-blue-400',
      features: ['Government Forms', 'Online Applications', 'Document Services', 'Digital Assistance']
    },
    {
      id: 'printing',
      icon: <Printer className="w-8 h-8" />,
      title: 'Xerox & Colour Print',
      description: 'Professional printing and photocopying services',
      color: 'from-red-400 to-pink-400',
      features: ['Color Printing', 'Black & White', 'Scanning', 'Lamination']
    },
    {
      id: 'online-applications',
      icon: <Megaphone className="w-8 h-8" />,
      title: 'All Online Applications',
      description: 'Complete online application and form services',
      color: 'from-indigo-400 to-purple-400',
      features: ['Form Filling', 'Document Upload', 'Application Tracking', 'Support Services']
    },
    {
      id: 'stationeries',
      icon: <BookOpen className="w-8 h-8" />,
      title: 'Stationeries',
      description: 'Complete range of office and school stationery items',
      color: 'from-teal-400 to-green-400',
      features: ['Office Supplies', 'School Items', 'Writing Materials', 'Art Supplies']
    },
    {
      id: 'pvc-cards',
      icon: <CreditCard className="w-8 h-8" />,
      title: 'PVC Card Print',
      description: 'Professional PVC card printing and customization',
      color: 'from-orange-400 to-red-400',
      features: ['ID Cards', 'Business Cards', 'Membership Cards', 'Custom Design']
    },
    {
      id: 'resin-art',
      icon: <Palette className="w-8 h-8" />,
      title: 'Resin Art Work',
      description: 'Creative resin art and craft services',
      color: 'from-pink-400 to-purple-400',
      features: ['Custom Designs', 'Decorative Items', 'Personalized Gifts', 'Art Pieces']
    },
    {
      id: 'book-labels',
      icon: <BookOpen className="w-8 h-8" />,
      title: 'Customised Book Labels',
      description: 'Personalized book labels and stickers',
      color: 'from-lime-400 to-green-400',
      features: ['Name Labels', 'Custom Designs', 'Waterproof', 'School Labels']
    }
  ];

  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="bg-gradient-to-r from-green-400 to-cyan-400 bg-clip-text text-transparent">
                OUR SERVICES
              </span>
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Comprehensive technology and business solutions under one roof
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => (
              <div
                key={service.id}
                className="group relative bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-800 hover:border-green-500/50 transition-all duration-300 hover:transform hover:scale-105"
              >
                {/* Icon */}
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-lg bg-gradient-to-r ${service.color} mb-4 text-white`}>
                  {service.icon}
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-green-400 transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed mb-4">
                  {service.description}
                </p>

                {/* Features */}
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm text-gray-300">
                      <div className="w-1.5 h-1.5 bg-green-400 rounded-full mr-2"></div>
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* Learn More Link */}
                <Link
                  to={`/services/${service.id}`}
                  className="inline-flex items-center space-x-2 text-green-400 hover:text-green-300 transition-colors font-medium"
                >
                  <span>Learn More</span>
                  <ArrowRight size={16} />
                </Link>

                {/* Hover Border Effect */}
                <div className="absolute inset-0 rounded-xl border-2 border-transparent group-hover:border-green-500/30 transition-all duration-300"></div>
              </div>
            ))}
          </div>

          {/* Call to Action */}
          <div className="text-center mt-16">
            <div className="inline-block p-8 bg-gradient-to-r from-gray-900 to-gray-800 rounded-xl border border-green-500/30">
              <h3 className="text-2xl font-bold text-green-400 mb-4">Need Our Services?</h3>
              <p className="text-gray-400 mb-6 max-w-md">
                Contact us for professional assistance and competitive pricing
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  to="/contact"
                  className="px-6 py-3 bg-gradient-to-r from-green-500 to-cyan-500 text-black font-bold rounded-lg hover:from-green-400 hover:to-cyan-400 transition-all duration-300"
                >
                  Get Quote Now
                </Link>
                <a
                  href="tel:7639814304"
                  className="px-6 py-3 border-2 border-green-500 text-green-400 font-bold rounded-lg hover:bg-green-500/10 transition-all duration-300"
                >
                  Call Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;