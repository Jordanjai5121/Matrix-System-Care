import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Phone, Mail } from 'lucide-react';

const ServiceDetail = () => {
  const { serviceId } = useParams();

  // Service details data
  const serviceDetails: Record<string, any> = {
    'mobile-service': {
      title: 'Mobile Service',
      description: 'Professional mobile phone repair and maintenance services with genuine parts and expert technicians.',
      features: [
        'Screen Replacement - All brands and models',
        'Battery Replacement - Original and compatible',
        'Software Issues - OS updates, app problems',
        'Water Damage Repair - Professional cleaning',
        'Charging Port Repair - USB-C, Lightning, Micro USB',
        'Camera Repair - Front and rear camera issues',
        'Speaker/Microphone Repair - Audio problems',
        'Button Repair - Power, volume, home buttons'
      ],
      pricing: 'Starting from ₹200 - Contact for specific repair quotes',
      warranty: '3-6 months warranty on repairs',
      turnaround: '1-3 days depending on repair complexity'
    },
    'computer-sales-service': {
      title: 'Computer Sales & Service',
      description: 'Complete computer solutions including sales of new systems, repairs, and maintenance services.',
      features: [
        'Hardware Repair - Motherboard, RAM, HDD/SSD',
        'Software Installation - OS, drivers, applications',
        'Virus Removal - Complete system cleaning',
        'Data Recovery - Lost file restoration',
        'System Upgrade - RAM, storage, graphics',
        'Network Setup - WiFi, LAN configuration',
        'Printer Setup - Installation and troubleshooting',
        'Custom PC Building - Gaming, office systems'
      ],
      pricing: 'Service: ₹300-₹1500 | New Systems: ₹25,000+',
      warranty: '6 months to 1 year on repairs',
      turnaround: '2-5 days for repairs'
    },
    'laptop-service': {
      title: 'Laptop Sales & Services',
      description: 'Comprehensive laptop services including sales, repairs, and performance optimization.',
      features: [
        'Screen Repair - LCD, LED, touch screens',
        'Keyboard Replacement - All layouts available',
        'Performance Upgrade - SSD, RAM upgrades',
        'Cooling System - Fan cleaning, thermal paste',
        'Battery Replacement - Extended life batteries',
        'Hinge Repair - Screen hinge problems',
        'Port Repair - USB, HDMI, audio jacks',
        'Motherboard Repair - Component level service'
      ],
      pricing: 'Service: ₹500-₹3000 | New Laptops: ₹30,000+',
      warranty: '3-6 months on repairs',
      turnaround: '2-7 days depending on parts availability'
    }
  };

  const service = serviceDetails[serviceId || ''];

  if (!service) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Service Not Found</h1>
          <Link
            to="/services"
            className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-green-500 to-cyan-500 text-black font-bold rounded-lg hover:from-green-400 hover:to-cyan-400 transition-all duration-300"
          >
            <ArrowLeft size={20} />
            <span>Back to Services</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20">
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {/* Back Button */}
            <Link
              to="/services"
              className="inline-flex items-center space-x-2 text-green-400 hover:text-green-300 transition-colors mb-8"
            >
              <ArrowLeft size={20} />
              <span>Back to Services</span>
            </Link>

            {/* Service Header */}
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                <span className="bg-gradient-to-r from-green-400 to-cyan-400 bg-clip-text text-transparent">
                  {service.title}
                </span>
              </h1>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto">
                {service.description}
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-12">
              {/* Service Details */}
              <div className="space-y-8">
                <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
                  <h3 className="text-2xl font-bold text-green-400 mb-4">What We Offer</h3>
                  <ul className="space-y-3">
                    {service.features.map((feature: string, index: number) => (
                      <li key={index} className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Service Info */}
                <div className="space-y-6">
                  <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
                    <h4 className="text-lg font-bold text-cyan-400 mb-2">Pricing</h4>
                    <p className="text-gray-300">{service.pricing}</p>
                  </div>

                  <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
                    <h4 className="text-lg font-bold text-blue-400 mb-2">Warranty</h4>
                    <p className="text-gray-300">{service.warranty}</p>
                  </div>

                  <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
                    <h4 className="text-lg font-bold text-purple-400 mb-2">Turnaround Time</h4>
                    <p className="text-gray-300">{service.turnaround}</p>
                  </div>
                </div>
              </div>

              {/* Contact & Booking */}
              <div className="space-y-8">
                <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-xl p-8 border border-green-500/30">
                  <h3 className="text-2xl font-bold text-green-400 mb-6">Get This Service</h3>
                  
                  <div className="space-y-4 mb-6">
                    <div className="flex items-center space-x-3">
                      <Phone className="w-5 h-5 text-green-400" />
                      <div>
                        <p className="text-white font-semibold">Call Us</p>
                        <p className="text-green-400">76398 14304</p>
                        <p className="text-cyan-400">96293 87725</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <Mail className="w-5 h-5 text-blue-400" />
                      <div>
                        <p className="text-white font-semibold">Email Us</p>
                        <p className="text-blue-400">matrixsystemcare19@gmail.com</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-4">
                    <a
                      href="tel:7639814304"
                      className="w-full px-6 py-3 bg-gradient-to-r from-green-500 to-cyan-500 text-black font-bold rounded-lg hover:from-green-400 hover:to-cyan-400 transition-all duration-300 text-center"
                    >
                      Call Now for Quote
                    </a>
                    <Link
                      to="/contact"
                      className="w-full px-6 py-3 border-2 border-green-500 text-green-400 font-bold rounded-lg hover:bg-green-500/10 transition-all duration-300 text-center"
                    >
                      Visit Our Shop
                    </Link>
                  </div>
                </div>

                {/* Why Choose Us */}
                <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
                  <h3 className="text-xl font-bold text-white mb-4">Why Choose Matrix System Care?</h3>
                  
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-green-400 rounded-full mt-2"></div>
                      <div>
                        <h4 className="font-semibold text-green-400">Expert Technicians</h4>
                        <p className="text-gray-400 text-sm">Experienced professionals with years of expertise</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full mt-2"></div>
                      <div>
                        <h4 className="font-semibold text-cyan-400">Genuine Parts</h4>
                        <p className="text-gray-400 text-sm">Only authentic spare parts and components</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-400 rounded-full mt-2"></div>
                      <div>
                        <h4 className="font-semibold text-blue-400">Competitive Pricing</h4>
                        <p className="text-gray-400 text-sm">Affordable rates with wholesale options</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-purple-400 rounded-full mt-2"></div>
                      <div>
                        <h4 className="font-semibold text-purple-400">Quick Service</h4>
                        <p className="text-gray-400 text-sm">Fast turnaround times for all repairs</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServiceDetail;