import React, { useState } from 'react';
import { X, Upload, Plus } from 'lucide-react';

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  // Sample gallery images - you can replace these with your actual images
  const galleryImages = [
    {
      id: 1,
      src: 'https://images.pexels.com/photos/163100/circuit-circuit-board-resistor-computer-163100.jpeg?auto=compress&cs=tinysrgb&w=800',
      alt: 'Computer Repair Work',
      category: 'Computer Service'
    },
    {
      id: 2,
      src: 'https://images.pexels.com/photos/1476321/pexels-photo-1476321.jpeg?auto=compress&cs=tinysrgb&w=800',
      alt: 'Mobile Phone Repair',
      category: 'Mobile Service'
    },
    {
      id: 3,
      src: 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=800',
      alt: 'Laptop Service',
      category: 'Laptop Service'
    },
    {
      id: 4,
      src: 'https://images.pexels.com/photos/4792728/pexels-photo-4792728.jpeg?auto=compress&cs=tinysrgb&w=800',
      alt: 'Electronics Accessories',
      category: 'Accessories'
    },
    {
      id: 5,
      src: 'https://images.pexels.com/photos/4792729/pexels-photo-4792729.jpeg?auto=compress&cs=tinysrgb&w=800',
      alt: 'Printing Services',
      category: 'Printing'
    },
    {
      id: 6,
      src: 'https://images.pexels.com/photos/159304/network-cable-ethernet-computer-159304.jpeg?auto=compress&cs=tinysrgb&w=800',
      alt: 'Network Setup',
      category: 'Computer Service'
    }
  ];

  const categories = ['All', 'Computer Service', 'Mobile Service', 'Laptop Service', 'Accessories', 'Printing'];
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredImages = activeCategory === 'All' 
    ? galleryImages 
    : galleryImages.filter(img => img.category === activeCategory);

  return (
    <div className="pt-20">
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="bg-gradient-to-r from-green-400 to-cyan-400 bg-clip-text text-transparent">
                OUR GALLERY
              </span>
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Showcasing our work and services through images
            </p>
          </div>

          {/* Upload Section for Admin */}
          <div className="mb-12 text-center">
            <div className="inline-block p-6 bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-800">
              <h3 className="text-lg font-bold text-green-400 mb-4">Add New Images</h3>
              <p className="text-gray-400 mb-4 text-sm">
                To add new images to the gallery, place them in the <code className="bg-gray-800 px-2 py-1 rounded">public/images</code> folder
                and update the gallery array in the Gallery component.
              </p>
              <div className="flex items-center justify-center space-x-2 text-cyan-400">
                <Upload size={20} />
                <span>Upload images to public/images folder</span>
              </div>
            </div>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                  activeCategory === category
                    ? 'bg-gradient-to-r from-green-500 to-cyan-500 text-black'
                    : 'bg-gray-800/80 text-gray-300 hover:text-green-400 border border-gray-700 hover:border-green-500/50'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Gallery Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredImages.map((image) => (
              <div
                key={image.id}
                className="group relative bg-gray-900/50 backdrop-blur-sm rounded-xl overflow-hidden border border-gray-800 hover:border-green-500/50 transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedImage(image.src)}
              >
                <div className="aspect-video overflow-hidden">
                  <img
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <div className="text-center">
                    <h3 className="text-white font-bold mb-1">{image.alt}</h3>
                    <p className="text-green-400 text-sm">{image.category}</p>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-white font-semibold mb-1">{image.alt}</h3>
                  <p className="text-green-400 text-sm">{image.category}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Add More Images Placeholder */}
          <div className="mt-12 text-center">
            <div className="inline-block p-8 bg-gray-900/30 backdrop-blur-sm rounded-xl border-2 border-dashed border-gray-700 hover:border-green-500/50 transition-all duration-300">
              <Plus className="w-12 h-12 text-gray-500 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-gray-400 mb-2">More Images Coming Soon</h3>
              <p className="text-gray-500 text-sm">
                We're constantly updating our gallery with new work samples
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Image Modal */}
      {selectedImage && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
          <div className="relative max-w-4xl max-h-full">
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute -top-12 right-0 text-white hover:text-green-400 transition-colors"
            >
              <X size={32} />
            </button>
            <img
              src={selectedImage}
              alt="Gallery Image"
              className="max-w-full max-h-full object-contain rounded-lg"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default Gallery;