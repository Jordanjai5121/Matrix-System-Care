// Content management system for easy updates
export interface ServiceData {
  id: string;
  title: string;
  description: string;
  features: string[];
  pricing: string;
  warranty: string;
  turnaround: string;
  category: string;
}

export interface GalleryImage {
  id: number;
  src: string;
  alt: string;
  category: string;
}

export interface BusinessInfo {
  name: string;
  tagline: string;
  owner: string;
  phones: string[];
  email: string;
  address: {
    line1: string;
    line2: string;
    line3: string;
    line4: string;
  };
  hours: {
    weekdays: string;
    sunday: string;
  };
}

// Business Information
export const businessInfo: BusinessInfo = {
  name: "Matrix System Care",
  tagline: "Mobile & Computer Sales & Service",
  owner: "Dhinesh G",
  phones: ["76398 14304", "96293 87725"],
  email: "matrixsystemcare19@gmail.com",
  address: {
    line1: "No.116G/3, Ammai Appar Complex,",
    line2: "E.B.Nagar, Rattinamangalam,",
    line3: "ARNI - 632 316.",
    line4: "T.V.Malai Dist."
  },
  hours: {
    weekdays: "Mon - Sat: 9:00 AM - 8:00 PM",
    sunday: "Sunday: 10:00 AM - 6:00 PM"
  }
};

// Services Data
export const servicesData: ServiceData[] = [
  {
    id: 'mobile-service',
    title: 'Mobile Service',
    description: 'Professional mobile phone repair and maintenance services with genuine parts and expert technicians.',
    features: [
      'Screen Replacement - All brands and models',
      'Battery Replacement - Original and compatible',
      'Software Issues - OS updates, app problems',
      'Water Damage Repair - Professional cleaning',
      'Charging Port Repair - USB-C, Lightning, Micro USB',
      'Camera Repair - Front and rear camera issues',
      'Speaker/Microphone Repair - Audio problems',
      'Button Repair - Power, volume, home buttons'
    ],
    pricing: 'Starting from ₹200 - Contact for specific repair quotes',
    warranty: '3-6 months warranty on repairs',
    turnaround: '1-3 days depending on repair complexity',
    category: 'Mobile Service'
  },
  {
    id: 'computer-sales-service',
    title: 'Computer Sales & Service',
    description: 'Complete computer solutions including sales of new systems, repairs, and maintenance services.',
    features: [
      'Hardware Repair - Motherboard, RAM, HDD/SSD',
      'Software Installation - OS, drivers, applications',
      'Virus Removal - Complete system cleaning',
      'Data Recovery - Lost file restoration',
      'System Upgrade - RAM, storage, graphics',
      'Network Setup - WiFi, LAN configuration',
      'Printer Setup - Installation and troubleshooting',
      'Custom PC Building - Gaming, office systems'
    ],
    pricing: 'Service: ₹300-₹1500 | New Systems: ₹25,000+',
    warranty: '6 months to 1 year on repairs',
    turnaround: '2-5 days for repairs',
    category: 'Computer Service'
  },
  {
    id: 'laptop-service',
    title: 'Laptop Sales & Services',
    description: 'Comprehensive laptop services including sales, repairs, and performance optimization.',
    features: [
      'Screen Repair - LCD, LED, touch screens',
      'Keyboard Replacement - All layouts available',
      'Performance Upgrade - SSD, RAM upgrades',
      'Cooling System - Fan cleaning, thermal paste',
      'Battery Replacement - Extended life batteries',
      'Hinge Repair - Screen hinge problems',
      'Port Repair - USB, HDMI, audio jacks',
      'Motherboard Repair - Component level service'
    ],
    pricing: 'Service: ₹500-₹3000 | New Laptops: ₹30,000+',
    warranty: '3-6 months on repairs',
    turnaround: '2-7 days depending on parts availability',
    category: 'Laptop Service'
  }
];

// Gallery Images - Add your images to public/images folder and update paths here
export const galleryImages: GalleryImage[] = [
  {
    id: 1,
    src: 'https://images.pexels.com/photos/163100/circuit-circuit-board-resistor-computer-163100.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Computer Repair Work',
    category: 'Computer Service'
  },
  {
    id: 2,
    src: 'https://images.pexels.com/photos/1476321/pexels-photo-1476321.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Mobile Phone Repair',
    category: 'Mobile Service'
  },
  {
    id: 3,
    src: 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Laptop Service',
    category: 'Laptop Service'
  },
  {
    id: 4,
    src: 'https://images.pexels.com/photos/4792728/pexels-photo-4792728.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Electronics Accessories',
    category: 'Accessories'
  },
  {
    id: 5,
    src: 'https://images.pexels.com/photos/4792729/pexels-photo-4792729.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Printing Services',
    category: 'Printing'
  },
  {
    id: 6,
    src: 'https://images.pexels.com/photos/159304/network-cable-ethernet-computer-159304.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Network Setup',
    category: 'Computer Service'
  }
];

// How to add new content:
// 1. For images: Add image files to public/images/ folder and update galleryImages array
// 2. For services: Add new service objects to servicesData array
// 3. For business info: Update businessInfo object
// 4. For new pages: Create new page components and add routes in App.tsx